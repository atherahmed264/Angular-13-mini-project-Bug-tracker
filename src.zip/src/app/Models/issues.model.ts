export interface issue {
    description:String,
    severity:String,
    status:String,
    date:Date,
    id?:number,
    count?:number,
}