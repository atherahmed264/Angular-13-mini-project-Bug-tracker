export interface User {
    Name : String,
    Email : String,
    Mobile : number,
    Country : String,
    Username : String,
    Password : String,
    id?:number,
}